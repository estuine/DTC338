﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class test_script_1 : MonoBehaviour {

	// defining variable, param2 is changeable in the editor
    private Rigidbody rb;
    public float parameter2 = 10;
	// Use this for initialization
	void Start () {
		// echos the sentence to the console
        print("Never name your script something this stupid, ever!");
        // sets rb to the rigidbody of the attached object
		rb = GetComponent<Rigidbody>();
	}
	
	// Update is called once per frame
	void Update () {
		// adds vertical force when W or S is pressd
        rb.AddRelativeForce(Vector3.up * parameter2 * Input.GetAxis("Vertical"));
        // adds torque when W or S is pressed
		rb.AddTorque(Vector3.left * parameter2 * Input.GetAxis("Vertical"));
	}
}
