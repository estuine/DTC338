﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript4 : MonoBehaviour {

    public float parameter1 = 100;
    public float parameter2 = 10;

	// Use this for initialization
	void Start () {
		
	}
	
	// checks for collision with object script is applied to
	void OnCollisionEnter(Collision collision)
    {
		// echos the name of the colliding object
        print(collision.collider.name);
		
		// if the object collides with the terrain
        if(collision.collider.name != "Terrain")
        {
			// sets param1 to be equal to param1-param2; would be better to write param1-=param2
            parameter1 = parameter1 - parameter2;
			// prints the new value
            print(parameter1);
        }
		// checks value of param1, to see if it's less than 0
        if(parameter1 < 0)
        {
			// deletes the connected object
            Destroy(gameObject);
        }
    }
}
