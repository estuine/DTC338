﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript5 : MonoBehaviour {
    
	// defining variables, all but 5 are editable through the unity editor
	public float parameter1 = 0.1f;
    public float parameter2 = 0.1f;
    public float parameter3 = 10;
    public float parameter4 = -10;
    private bool parameter5 = true;
	// Use this for initialization
	void Start () {
		
	}
	
	// Update is called once per frame
	void Update () {
		// checks the current value of params1 and 3. if 1 is larger then param5 is set to false
        if(parameter1 > parameter3)
        {
            parameter5 = false;
        }
		
		// checks if param5 is true
        if (parameter5)
        {
			// sets param1 to param1+param2
            parameter1 += parameter2;
			// sets the exposure element of the skybox to param1
            RenderSettings.skybox.SetFloat("_Exposure", parameter1);
        } else
        {
			// param1 is set to param1-param2
            parameter1 -= parameter2;
			// sets the exposure element of the skybox to param1
            RenderSettings.skybox.SetFloat("_Exposure", parameter1);
        }
		// checks if param 4 is greater than param1
        if(parameter1 < parameter4)
        {
			// sets param5 to true
            parameter5 = true;
        }

    }
}
