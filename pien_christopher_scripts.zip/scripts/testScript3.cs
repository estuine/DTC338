﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class testScript3 : MonoBehaviour
{

	// defining variables
	
	// the object to be cloned is defined in the unity editor
    public GameObject parameter1;
    // defaults param2 to 20, but is editable in unity editor
	public float parameter2 = 20;
    private GameObject clone;
    // Update is called once per frame
    void Update()
    {
		// checks for MB1/fire1
        if (Input.GetButtonDown("Fire1"))
        {
			// creates a clone of the object, in the same position with the same rotation as the original
            clone = Instantiate(parameter1, transform.position, transform.rotation) as GameObject;
			
			//adds forward force to the clone based on its rotation and the value of param2
            clone.GetComponent<Rigidbody>().AddForce(clone.transform.forward * parameter2);
        }
    }
}
