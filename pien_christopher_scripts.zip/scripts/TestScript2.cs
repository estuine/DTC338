﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class TestScript2 : MonoBehaviour {
    // defining variables
	private Rigidbody rb;
    public float parameter1;
    private Renderer rend;
	// Use this for initialization
	void Start () {
		//setting rb to the object's rigidbody
        rb = GetComponent<Rigidbody>();
		// setting rend to the object's renderer
        rend = GetComponent<Renderer>();
	}
	
    void Update()
    {
		// checks for MB1 or "fire1" depending on system
        if (Input.GetButtonDown("Fire1"))
        {
			// generates a random color
            Color color = Random.ColorHSV();
			// asigns the random color to the object the script is attached to
            rend.material.SetColor("_Color", color);
            
        }
    }
	// activates on collision
	void OnCollisionEnter(Collision collision)
    {
		// ads vertical motion multiplied by whatever the float value of param 1 is set to via the unity editor
        rb.AddForce(Vector3.up * parameter1);
    }
}
